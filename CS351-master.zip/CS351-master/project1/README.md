Instructions:

1. compile and run "createInputFile.cpp"
2. enter in a filename you'd like to create. 
3. enter the number of items and knapsack capacity

this will create a file with n number of items and assign random values and weights to each item.

4. compile and run "driver.cpp"
5. enter in the filename you previously created

this will output the number of items, total weight, and total profit of the knapsack. Then, each item in the knapsack will be printed out displaying its name, value and weight
